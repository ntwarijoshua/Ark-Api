# Ark-Api
A P.O.S Cloud Service Api


To Run this project follow the steps below <br/>
Pre-requisites: Go language, Glide Dependency Manager <br/>
1.Clone the repository <br/>
2.Create a ".env" file to hold your environment variables <br/>
3.Run `Glide install` to install all dependencies <br/>
4.Run `bee run` to start the http server <br/>
